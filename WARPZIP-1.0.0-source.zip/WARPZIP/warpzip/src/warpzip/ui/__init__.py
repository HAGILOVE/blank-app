"""WARPZIP GUI (PySide6)."""
